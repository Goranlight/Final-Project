// Get the dropdown menu and add a click event listener to each link
const dropdownMenu = document.querySelector('.dropdown-content');
const links = dropdownMenu.getElementsByTagName('a');

// Get the "Select all" checkbox and add a click event listener to it
const selectAllCheckbox = document.getElementById('select-all');
selectAllCheckbox.addEventListener('click', function () {
  // Loop through all the links and check them
  for (let i = 0; i < links.length; i++) {
    links[i].checked = true;
  }
  // Check the "Deselect all" checkbox
  deselectAllCheckbox.checked = false;
});

// Get the "Deselect all" checkbox and add a click event listener to it
const deselectAllCheckbox = document.getElementById('deselect-all');
deselectAllCheckbox.addEventListener('click', function () {
  for (let i = 0; i < links.length; i++) {
    links[i].checked = false;
  }
  selectAllCheckbox.checked = false;
});

// Get the "Download all" button and add a click event listener to it
const downloadAllButton = document.getElementById('download-all');
downloadAllButton.addEventListener('click', function () {
  // Code to download all selected source files goes here
});

// Get the "View selected" button and add a click event listener to it
const viewSelectedButton = document.getElementById('view-selected');
viewSelectedButton.addEventListener('click', function () {
  for (let i = 0; i < links.length; i++) {
    if (links[i].checked) {
      // Extract the subunit name from the link's href attribute
      const unit = links[i].href.split('/')[2].split('.')[0];
      // Call the openSourcePage function with the subunit name as a parameter
      openSourcePage(unit);
    }
  }
});

// Get the "Cancel" button and add a click event listener to it
const cancelButton = document.getElementById('cancel');
cancelButton.addEventListener('click', function () {
  // Code to clear the user's selection and close the dropdown menu goes here
});

// Function to open the source page for the given subunit
function openSourcePage(unit) {
  window.open(`source_${unit}.html`, '_blank');
}

// Add event listeners to each link
for (let i = 0; i < links.length; i++) {
  links[i].addEventListener('click', function () {
    // Extract the subunit name from the link's href attribute
    const unit = links[i].href.split('/')[2].split('.')[0];
    // Call the openSourcePage function with the subunit name as a parameter
    openSourcePage(unit);
  });

  links[i].addEventListener('change', function () {
    if (links[i].checked) {
      // If the link is checked, uncheck the "Select all" checkbox
      selectAllCheckbox.checked = false;
    }
  });
}

// Set the "Deselect all" checkbox to be checked if none of the links are checked
deselectAllCheckbox.checked = !Array.from(links).some(link => link.checked);